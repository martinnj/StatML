To run all of the code together, run the matlab file runAll.m
Each of the assignments has a corresponding .m file, for example
the code for assignment I.4.1 is contained in I_4_1.m while the code
for assignment I.2.2 is contained in I_2_2.m
