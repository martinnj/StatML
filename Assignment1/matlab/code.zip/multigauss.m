function y = multigauss( mu, L, z )
    y = mu + L*z;

end

